# 1 Public Updates
- Added blog system (w.i.p, see to-do for more)
- Explanatory comments in javascript
- Added more in-depth notes to the css, along with references for newbs

# 2 To-Do
- Dynamically optional content
- Auto scroll control when blog is open
